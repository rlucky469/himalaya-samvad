import type { ReactNode } from "react";
import { env } from "@/config/env";
import { FormAlert } from "@/components/forms/FormAlert";

export function AuthCard({ title, subtitle, children, footer, mockNotice }: { title: string; subtitle?: ReactNode; children: ReactNode; footer?: ReactNode; mockNotice?: string }) {
  return (
    <div>
      <div className="rounded-panel border border-line bg-surface p-6 shadow-lift sm:p-9">
        <h1 className="text-3xl sm:text-[2.1rem]">{title}</h1>
        {subtitle && <p className="mt-2 text-ink-soft">{subtitle}</p>}
        {env.useMockApi && mockNotice && (
          <FormAlert tone="info" className="mt-5">
            {mockNotice}
          </FormAlert>
        )}
        <div className="mt-7">{children}</div>
      </div>
      {footer && <div className="mt-6 text-center text-ink-soft">{footer}</div>}
    </div>
  );
}
