"use client";

import { motion } from "motion/react";
import { BookOpen, CheckCircle2, Mail, Smartphone } from "lucide-react";
import { useTranslations } from "next-intl";
import { useEffect, useState } from "react";
import { Link } from "@/i18n/navigation";
import { OtpInput } from "@/components/forms/fields/OtpInput";
import { FormAlert } from "@/components/forms/FormAlert";
import { Button, ButtonLink } from "@/components/ui/Button";
import { useSubmitError } from "@/components/forms/useSubmitError";
import { authService } from "@/services/auth.service";
import { flowStore, type PendingVerification } from "@/services/api/session-storage";
import { useAuth } from "@/providers/AuthProvider";
import { OTP_RE } from "@/lib/validation/schemas";
import { routes } from "@/config/routes";
import type { AuthSession, OtpChannel } from "@/types/api";
import { useCountdown } from "./useCountdown";
import { cn } from "@/lib/utils";

const RESEND_SECONDS = 30;

function ChannelBlock({ channel, target, userId, verified, onVerified }: { channel: OtpChannel; target: string; userId: string; verified: boolean; onVerified: (session?: AuthSession) => void }) {
  const t = useTranslations("auth.verify");
  const tv = useTranslations("validation");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const { seconds, restart } = useCountdown(RESEND_SECONDS);
  const toMessage = useSubmitError();
  const Icon = channel === "mobile" ? Smartphone : Mail;
  const shownTarget = channel === "mobile" ? `+91 ${target}` : target;

  const verify = async () => {
    if (!OTP_RE.test(otp)) return setError(tv("otpInvalid"));
    setBusy(true);
    setError("");
    try {
      const res = await authService.verifyOtp({ userId, channel, target, otp });
      onVerified(res.session);
    } catch (e) {
      setError(toMessage(e) || tv("otpInvalid"));
    } finally {
      setBusy(false);
    }
  };

  const resend = async () => {
    setError("");
    try {
      const res = await authService.sendOtp({ userId, channel, target, purpose: "verify" });
      restart(res.retryAfterSeconds ?? RESEND_SECONDS);
      setInfo(t("otpSent"));
    } catch (e) {
      setError(toMessage(e));
    }
  };

  return (
    <section className={cn("rounded-card border p-5 transition-colors", verified ? "border-nature/40 bg-nature-soft" : "border-line bg-surface")}>
      <div className="flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-2 font-sans text-lg font-bold text-primary">
          <Icon aria-hidden className="size-5 text-cta" />
          {channel === "mobile" ? t("mobileTitle") : t("emailTitle")}
        </h2>
        {verified && (
          <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="inline-flex items-center gap-1 rounded-full bg-nature px-2.5 py-1 text-xs font-bold text-white">
            <CheckCircle2 className="size-3.5" />
            {t("verified")}
          </motion.span>
        )}
      </div>
      {!verified && (
        <>
          <p className="mt-2 text-sm text-ink-soft">{t(channel === "mobile" ? "mobileText" : "emailText", { target: shownTarget })}</p>
          <div className="mt-4">
            <OtpInput id={`otp-${channel}`} label={channel === "mobile" ? t("mobileTitle") : t("emailTitle")} value={otp} onChange={(v) => { setOtp(v); setError(""); }} invalid={!!error} disabled={busy} />
          </div>
          {error && <p role="alert" className="mt-2 text-sm font-medium text-accent">{error}</p>}
          {info && !error && <p role="status" className="mt-2 text-sm text-nature">{info}</p>}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <Button type="button" size="sm" variant="navy" onClick={verify} disabled={busy || otp.length < 6}>
              {t("verifyButton")}
            </Button>
            <button type="button" onClick={resend} disabled={seconds > 0} className="text-sm font-semibold text-primary hover:text-accent disabled:cursor-not-allowed disabled:text-muted">
              {seconds > 0 ? t("resendIn", { seconds }) : t("resend")}
            </button>
          </div>
        </>
      )}
    </section>
  );
}

export function VerifyForm() {
  const t = useTranslations("auth.verify");
  const tr = useTranslations("auth.register");
  const { signIn } = useAuth();
  const [pending, setPending] = useState<PendingVerification | null | undefined>(undefined);
  const [verified, setVerified] = useState<Record<OtpChannel, boolean>>({ mobile: false, email: false });
  const [session, setSession] = useState<AuthSession | undefined>();
  const steps = t.raw("steps") as string[];

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- pending data lives in sessionStorage
    setPending(flowStore.getVerification());
  }, []);

  // Channels the user didn't provide (e.g. login with only one identifier) count as done
  const needs = { mobile: Boolean(pending?.mobile), email: Boolean(pending?.email) };
  const complete = pending && (!needs.mobile || verified.mobile) && (!needs.email || verified.email);

  useEffect(() => {
    if (!complete) return;
    if (session) signIn(session, true);
    flowStore.clearVerification();
  }, [complete, session, signIn]);

  if (pending === undefined) return <div className="h-64 animate-pulse rounded-card bg-mist" />;
  if (!pending)
    return (
      <FormAlert tone="info">
        {t("missing")}{" "}
        <Link href={routes.register} className="font-semibold underline">
          {tr("title")}
        </Link>
      </FormAlert>
    );

  const onVerified = (channel: OtpChannel) => (s?: AuthSession) => {
    setVerified((v) => ({ ...v, [channel]: true }));
    if (s) setSession(s);
  };
  const stepIndex = complete ? 2 : 1;

  return (
    <div className="space-y-5">
      <ol className="flex items-center gap-2" aria-label={t("title")}>
        {steps.map((step, i) => (
          <li key={step} className="flex flex-1 items-center gap-2">
            <span className={cn("inline-flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-bold", i <= stepIndex ? "bg-primary text-white" : "bg-mist text-muted")}>
              {i < stepIndex ? <CheckCircle2 className="size-4" /> : i + 1}
            </span>
            <span className={cn("text-sm font-semibold", i <= stepIndex ? "text-primary" : "text-muted")}>{step}</span>
            {i < steps.length - 1 && <span aria-hidden className={cn("h-0.5 flex-1 rounded-full", i < stepIndex ? "bg-primary" : "bg-line")} />}
          </li>
        ))}
      </ol>

      {complete ? (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="rounded-card border border-nature/30 bg-nature-soft p-6 text-center">
          <CheckCircle2 className="mx-auto size-12 text-nature" />
          <h2 className="mt-3 text-2xl">{t("doneTitle")}</h2>
          <p className="mt-2 text-ink-soft">{t("doneText")}</p>
          <ButtonLink href={routes.currentIssueReader} className="mt-5 w-full" icon={<BookOpen />} iconPosition="start">
            {t("doneCta")}
          </ButtonLink>
        </motion.div>
      ) : (
        <>
          {needs.mobile && <ChannelBlock channel="mobile" target={pending.mobile} userId={pending.userId} verified={verified.mobile} onVerified={onVerified("mobile")} />}
          {needs.email && <ChannelBlock channel="email" target={pending.email} userId={pending.userId} verified={verified.email} onVerified={onVerified("email")} />}
          <Link href={routes.register} className="block text-center text-sm font-semibold text-primary hover:text-accent">
            {t("changeDetails")}
          </Link>
        </>
      )}
    </div>
  );
}
