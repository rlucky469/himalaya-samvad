"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "motion/react";
import { CheckCircle2, LogIn, ShieldCheck } from "lucide-react";
import { useTranslations } from "next-intl";
import { useEffect, useState } from "react";
import { Controller, useForm, useWatch } from "react-hook-form";
import { Link } from "@/i18n/navigation";
import { OtpInput } from "@/components/forms/fields/OtpInput";
import { PasswordField } from "@/components/forms/fields/PasswordField";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { FormAlert } from "@/components/forms/FormAlert";
import { ButtonLink } from "@/components/ui/Button";
import { useSubmitError } from "@/components/forms/useSubmitError";
import { resetSchema } from "@/lib/validation/schemas";
import { authService, buildResetPayload } from "@/services/auth.service";
import { flowStore, type PendingReset } from "@/services/api/session-storage";
import { routes } from "@/config/routes";
import { useCountdown } from "./useCountdown";

export function ResetPasswordForm() {
  const t = useTranslations("auth.reset");
  const tvf = useTranslations("auth.verify");
  const tf = useTranslations("forms");
  const tv = useTranslations("validation");
  const [pending, setPending] = useState<PendingReset | null | undefined>(undefined);
  const [done, setDone] = useState(false);
  const [serverError, setServerError] = useState("");
  const { seconds, restart } = useCountdown(30);
  const form = useForm({ resolver: zodResolver(resetSchema), defaultValues: { otp: "", password: "", confirmPassword: "" }, mode: "onTouched" });
  const { register, handleSubmit, control, formState } = form;
  const { errors, isSubmitting } = formState;
  const password = useWatch({ control, name: "password" });
  const toMessage = useSubmitError(form.setError);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- pending data lives in sessionStorage
    setPending(flowStore.getReset());
  }, []);

  if (pending === undefined) return <div className="h-64 animate-pulse rounded-card bg-mist" />;

  if (done)
    return (
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="text-center">
        <CheckCircle2 className="mx-auto size-14 text-nature" />
        <h2 className="mt-3 text-2xl">{t("successTitle")}</h2>
        <p className="mt-2 text-ink-soft">{t("successText")}</p>
        <ButtonLink href={routes.login} className="mt-6 w-full" icon={<LogIn />} iconPosition="start">
          {t("loginCta")}
        </ButtonLink>
      </motion.div>
    );

  if (!pending)
    return (
      <FormAlert tone="info">
        {t("missing")}{" "}
        <Link href={routes.forgotPassword} className="font-semibold underline">
          {tvf("sendOtp")}
        </Link>
      </FormAlert>
    );

  const onSubmit = handleSubmit(async (values) => {
    setServerError("");
    try {
      await authService.resetPassword(buildResetPayload(pending.identifier, values));
      flowStore.clearReset();
      setDone(true);
    } catch (error) {
      setServerError(toMessage(error));
    }
  });

  const resend = async () => {
    try {
      await authService.forgotPassword({ identifier: pending.identifier, identifierType: pending.identifierType });
      restart(30);
    } catch (error) {
      setServerError(toMessage(error));
    }
  };

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <p className="text-sm text-ink-soft">{t("subtitle", { target: pending.maskedTarget })}</p>
      <div>
        <p className="mb-2 text-sm font-semibold text-ink">{tf("fields.otp")}</p>
        <Controller control={control} name="otp" render={({ field }) => <OtpInput id="reset-otp" label={tf("fields.otp")} value={field.value} onChange={field.onChange} invalid={!!errors.otp} />} />
        {errors.otp?.message && <p role="alert" className="mt-2 text-sm font-medium text-accent">{tv(errors.otp.message as never)}</p>}
        <button type="button" onClick={resend} disabled={seconds > 0} className="mt-3 text-sm font-semibold text-primary hover:text-accent disabled:text-muted">
          {seconds > 0 ? tvf("resendIn", { seconds }) : tvf("resend")}
        </button>
      </div>
      <PasswordField id="reset-password" label={tf("fields.password")} placeholder={tf("fields.passwordPlaceholder")} autoComplete="new-password" required showStrength value={password} error={errors.password?.message} {...register("password")} />
      <PasswordField id="reset-confirm" label={tf("fields.confirmPassword")} placeholder={tf("fields.confirmPasswordPlaceholder")} autoComplete="new-password" required error={errors.confirmPassword?.message} {...register("confirmPassword")} />
      {serverError && <FormAlert>{serverError}</FormAlert>}
      <SubmitButton loading={isSubmitting} loadingLabel={tf("submit.sending")} icon={<ShieldCheck />} className="w-full">
        {t("submit")}
      </SubmitButton>
    </form>
  );
}
