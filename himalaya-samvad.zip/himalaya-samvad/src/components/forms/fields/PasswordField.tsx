"use client";

import { Eye, EyeOff } from "lucide-react";
import { useTranslations } from "next-intl";
import { useState, type ComponentProps } from "react";
import { passwordStrength } from "@/lib/validation/schemas";
import { FormField, describedBy, inputClasses, type FieldBaseProps } from "./FormField";
import { cn } from "@/lib/utils";

type PasswordFieldProps = FieldBaseProps & Omit<ComponentProps<"input">, "id" | "className" | "type"> & { showStrength?: boolean; value?: string };

const strengthColors = ["bg-accent", "bg-cta", "bg-secondary", "bg-nature"];

export function PasswordField({ id, label, required, hint, error, className, showStrength, value = "", ...props }: PasswordFieldProps) {
  const t = useTranslations("auth.password");
  const [visible, setVisible] = useState(false);
  const score = passwordStrength(value);
  const labels = t.raw("strength") as string[];

  return (
    <FormField id={id} label={label} required={required} hint={hint} error={error} className={className}>
      <div className="relative">
        <input
          id={id}
          type={visible ? "text" : "password"}
          aria-invalid={!!error}
          aria-required={required}
          aria-describedby={describedBy(id, error, hint)}
          className={inputClasses(!!error) + " pr-12"}
          {...props}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? t("hide") : t("show")}
          aria-pressed={visible}
          className="absolute right-2 top-1/2 inline-flex size-9 -translate-y-1/2 items-center justify-center rounded-lg text-muted hover:bg-mist hover:text-primary"
        >
          {visible ? <EyeOff className="size-4.5" /> : <Eye className="size-4.5" />}
        </button>
      </div>
      {showStrength && value.length > 0 && (
        <div className="mt-1 flex items-center gap-3" aria-live="polite">
          <div className="flex flex-1 gap-1" aria-hidden>
            {[0, 1, 2, 3].map((i) => (
              <span key={i} className={cn("h-1.5 flex-1 rounded-full transition-colors duration-300", i <= score ? strengthColors[score] : "bg-line")} />
            ))}
          </div>
          <span className="text-xs font-semibold text-ink-soft">
            {t("strengthLabel")}: {labels[score]}
          </span>
        </div>
      )}
    </FormField>
  );
}
