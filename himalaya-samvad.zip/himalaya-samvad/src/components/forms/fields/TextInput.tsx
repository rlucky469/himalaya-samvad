"use client";

import type { ComponentProps } from "react";
import { FormField, describedBy, inputClasses, type FieldBaseProps } from "./FormField";
import { cn } from "@/lib/utils";

type TextInputProps = FieldBaseProps & Omit<ComponentProps<"input">, "id" | "className"> & { inputClassName?: string; prefix?: string };

export function TextInput({ id, label, required, optional, hint, error, className, inputClassName, prefix, ...inputProps }: TextInputProps) {
  const input = (
    <input
      id={id}
      aria-invalid={!!error}
      aria-required={required}
      aria-describedby={describedBy(id, error, hint)}
      className={cn(inputClasses(!!error), prefix && "rounded-l-none", inputClassName)}
      {...inputProps}
    />
  );
  return (
    <FormField id={id} label={label} required={required} optional={optional} hint={hint} error={error} className={className}>
      {prefix ? (
        <div className="flex">
          <span className="inline-flex items-center rounded-l-xl border border-r-0 border-line-strong bg-mist px-3.5 text-sm font-semibold text-ink-soft">
            {prefix}
          </span>
          {input}
        </div>
      ) : (
        input
      )}
    </FormField>
  );
}
