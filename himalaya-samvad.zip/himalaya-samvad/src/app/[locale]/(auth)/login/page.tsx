import type { Metadata } from "next";
import { Suspense } from "react";
import { getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import { AuthCard } from "@/components/auth/AuthCard";
import { LoginForm } from "@/components/auth/LoginForm";
import { buildMetadata } from "@/lib/seo";
import { initPage } from "@/lib/page";
import { routes } from "@/config/routes";

export async function generateMetadata({ params }: PageProps<"/[locale]/login">): Promise<Metadata> {
  const { locale } = await initPage(params);
  return buildMetadata({ locale, path: routes.login, seoKey: "login", noIndex: true });
}

export default async function LoginPage({ params }: PageProps<"/[locale]/login">) {
  await initPage(params);
  const t = await getTranslations("auth");
  return (
    <AuthCard
      title={t("login.title")}
      subtitle={t("login.subtitle")}
      mockNotice={t("mockNotice")}
      footer={
        <>
          {t("login.noAccount")}{" "}
          <Link href={routes.register} className="font-semibold text-primary hover:text-accent">
            {t("login.registerLink")}
          </Link>
        </>
      }
    >
      <Suspense fallback={<div className="h-72 animate-pulse rounded-card bg-mist" />}>
        <LoginForm />
      </Suspense>
    </AuthCard>
  );
}
