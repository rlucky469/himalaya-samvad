import type { Metadata } from "next";
import { getTranslations } from "next-intl/server";
import { AuthCard } from "@/components/auth/AuthCard";
import { VerifyForm } from "@/components/auth/VerifyForm";
import { buildMetadata } from "@/lib/seo";
import { initPage } from "@/lib/page";
import { routes } from "@/config/routes";

export async function generateMetadata({ params }: PageProps<"/[locale]/verify">): Promise<Metadata> {
  const { locale } = await initPage(params);
  return buildMetadata({ locale, path: routes.verify, seoKey: "verify", noIndex: true });
}

export default async function VerifyPage({ params }: PageProps<"/[locale]/verify">) {
  await initPage(params);
  const t = await getTranslations("auth");
  return (
    <AuthCard title={t("verify.title")} subtitle={t("verify.subtitle")} mockNotice={t("mockNotice")}>
      <VerifyForm />
    </AuthCard>
  );
}
