import Image from "next/image";
import { CheckCircle2, Home } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import { Logo } from "@/components/layout/Logo";
import { LanguageSwitcher } from "@/components/layout/LanguageSwitcher";
import { routes } from "@/config/routes";
import { media } from "@/lib/media";
import type { AppLocale } from "@/i18n/routing";

export default async function AuthLayout({ children, params }: LayoutProps<"/[locale]">) {
  setRequestLocale((await params).locale as AppLocale);
  const t = await getTranslations("auth.panel");
  const tb = await getTranslations("brand");
  const tc = await getTranslations("common");
  const points = t.raw("points") as string[];

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.1fr]">
      {/* Brand panel (desktop) */}
      <aside className="relative isolate hidden overflow-hidden bg-primary-deep text-white lg:flex lg:flex-col lg:justify-between lg:p-12 xl:p-16">
        <Image src={media.auth.panel} alt="" fill priority sizes="50vw" className="-z-20 animate-ken-burns object-cover opacity-50" />
        <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-t from-primary-deep via-primary-deep/80 to-primary/40" />
        <Logo name={tb("name")} tagline={tb("tagline")} tone="dark" />
        <div className="max-w-md animate-fade-up">
          <h2 className="text-4xl text-white xl:text-5xl">{t("title")}</h2>
          <p className="mt-4 text-lg text-on-dark-muted">{t("text")}</p>
          <ul className="mt-8 space-y-3.5">
            {points.map((point) => (
              <li key={point} className="flex items-center gap-3 text-lg">
                <CheckCircle2 aria-hidden className="size-5 shrink-0 text-cta" />
                {point}
              </li>
            ))}
          </ul>
        </div>
        <p className="font-serif italic text-white/80">{(tb.raw("closingLines") as string[]).join(" ")}</p>
      </aside>

      {/* Form side */}
      <div className="flex flex-col bg-canvas">
        <header className="flex items-center justify-between gap-4 px-5 py-5 sm:px-10">
          <div className="lg:invisible">
            <Logo name={tb("name")} tagline={tb("tagline")} size="sm" />
          </div>
          <div className="flex items-center gap-2">
            <Link href={routes.home} className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium text-ink-soft hover:bg-mist hover:text-primary">
              <Home aria-hidden className="size-4" />
              <span className="hidden sm:inline">{tc("home")}</span>
            </Link>
            <LanguageSwitcher />
          </div>
        </header>
        <main id="main" className="flex flex-1 items-start justify-center px-5 pb-16 pt-4 sm:items-center sm:px-10">
          <div className="w-full max-w-md animate-fade-up">{children}</div>
        </main>
      </div>
    </div>
  );
}
