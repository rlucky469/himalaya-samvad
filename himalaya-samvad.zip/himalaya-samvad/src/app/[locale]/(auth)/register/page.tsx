import type { Metadata } from "next";
import { getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import { AuthCard } from "@/components/auth/AuthCard";
import { RegisterForm } from "@/components/auth/RegisterForm";
import { buildMetadata } from "@/lib/seo";
import { initPage } from "@/lib/page";
import { routes } from "@/config/routes";

export async function generateMetadata({ params }: PageProps<"/[locale]/register">): Promise<Metadata> {
  const { locale } = await initPage(params);
  return buildMetadata({ locale, path: routes.register, seoKey: "register", noIndex: true });
}

export default async function RegisterPage({ params }: PageProps<"/[locale]/register">) {
  await initPage(params);
  const t = await getTranslations("auth");
  return (
    <AuthCard
      title={t("register.title")}
      subtitle={t("register.subtitle")}
      mockNotice={t("mockNotice")}
      footer={
        <>
          {t("register.haveAccount")}{" "}
          <Link href={routes.login} className="font-semibold text-primary hover:text-accent">
            {t("register.loginLink")}
          </Link>
        </>
      }
    >
      <RegisterForm />
    </AuthCard>
  );
}
